package com.sx.takeaway.ui.fragment;

import android.support.v4.app.Fragment;

/**
 * @Author sunxin
 * @Date 2017/5/21 22:16
 * @Description
 */

public class BaseFragment extends Fragment {
}
