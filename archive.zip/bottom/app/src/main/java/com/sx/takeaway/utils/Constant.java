package com.sx.takeaway.utils;

/**
 * @Author sunxin
 * @Date 2017/5/19 22:49
 * @Description 常量类
 */

public interface Constant {
    // http://localhost:8080/   TakeoutService    /login?username="itheima"&password="bj"

    String BASE_URL="http://localhost:8080/";
    String LOGIN = "TakeoutService/login";//登录
}
