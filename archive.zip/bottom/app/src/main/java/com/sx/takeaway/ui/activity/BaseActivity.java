package com.sx.takeaway.ui.activity;

import android.support.v7.app.AppCompatActivity;

/**
 * @Author sunxin
 * @Date 2017/5/21 22:16
 * @Description
 */

public class BaseActivity extends AppCompatActivity {
}
