package com.sx.mvp.model;

/**
 * @Author sunxin
 * @Date 2017/5/19 18:00
 * @Description
 */

public class User {
    public String username;
    public String password;
}
