package com.sx.mvp.model.net;

/**
 * @Author sunxin
 * @Date 2017/5/19 22:48
 * @Description
 */

public class ResponseInfo {
    public String code;
    public String data;
}
